package helloworld;

public class Welcome {
	public String sayWelcome(String name) {
		return "custom file "+name;
	}

}
