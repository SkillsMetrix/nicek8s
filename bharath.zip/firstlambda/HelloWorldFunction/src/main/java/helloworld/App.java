package helloworld;

public class App {

	public String hello(String name) {
		return "Lambda Functions are super easy and awesome!! " + name;
	}

}
